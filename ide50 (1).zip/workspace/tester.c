#define _XOPEN_SOURCE
#include <unistd.h>
# include <cs50.h>
# include <stdio.h>
# include <ctype.h>
# include <string.h>

int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./crack hash");
        return 1;
    }

    string salt = "50";
    string check = argv[1];

    char letter[5];

    //one character passwords
    for (int i = 0; i <= 51; i++)
    {
        letter[1] = '\0';
        if (i >= 0 && i <= 25)
        {
            letter[0] = i + 65;
            string pass = crypt(letter, salt);
            if (strcmp(argv[1], pass) == 0)
            {
                printf("%s\n", letter);
                return 0;
            }
        }
        else if (i >= 26 && i <= 51)
        {
            letter[0] = i + 71;
            string pass = crypt(letter, salt);
            if (strcmp(argv[1], pass) == 0)
            {
                printf("%s\n", letter);
                return 0;
            }
        }
    }

    //two character passwords
    for (int j = 0; j <= 51; j++)
    {
        letter[2] = '\0';
        if (j >= 0 && j <= 25)
        {
            letter[0] = j + 65;
            for (int i = 0; i <= 51; i++)
            {
                if (i >= 0 && i <= 25)
                {
                    letter[1] = i + 65;
                    string pass = crypt(letter, salt);
                    if (strcmp(argv[1], pass) == 0)
                    {
                        printf("%s\n", letter);
                        return 0;
                    }
                }
                else if (i >= 26 && i <= 51)
                {
                    letter[1] = i + 71;
                    string pass = crypt(letter, salt);
                    if (strcmp(argv[1], pass) == 0)
                    {
                        printf("%s\n", letter);
                        return 0;
                    }
                }
            }
        }

        if (j <= 26 && j <= 51)
        {
            letter[0] = j + 97;

            for (int i = 0; i <= 51; i++)
            {
                if (i >= 0 && i <= 25)
                {
                    letter[1] = i + 65;
                    string pass = crypt(letter, salt);
                    if (strcmp(argv[1], pass) == 0)
                    {
                        printf("%s\n", letter);
                        return 0;
                    }
                }
                else if (i >= 26 && i <= 51)
                {
                    letter[1] = i + 71;
                    string pass = crypt(letter, salt);
                    if (strcmp(argv[1], pass) == 0)
                    {
                        printf("%s\n", letter);
                        return 0;
                    }
                }
            }
        }
    }

    //three character passwords
    char word[4];
    for (int n = 0; n <= 51; n++)
    {
        word[3] = '\0';
        if (n >= 0 && n <= 25)
        {
            word[0] = n + 65;
            for (int j = 0; j <= 51; j++)
            {
                if (j >= 0 && j <= 25)
                {
                    word[1] = j + 65;
                    for (int i = 0; i <= 51; i++)
                    {
                        if (i >= 0 && i <= 25)
                        {
                            word[2] = i + 65;
                            string pass = crypt(word, salt);
                            if (strcmp(argv[1], pass) == 0)
                            {
                                printf("%s\n", word);
                                return 0;
                            }
                        }
                        else if (i >= 26 && i <= 51)
                        {
                            word[2] = i + 71;
                            string pass = crypt(word, salt);
                            if (strcmp(argv[1], pass) == 0)
                            {
                                printf("%s\n", word);
                                return 0;
                            }
                        }
                    }
                }
                if (j <= 26 && j <= 51)
                {
                    word[1] = j + 71;
                    for (int i = 0; i <= 51; i++)
                    {
                        if (i >= 0 && i <= 25)
                        {
                            word[2] = i + 65;
                            string pass = crypt(word, salt);
                            if (strcmp(argv[1], pass) == 0)
                            {
                                printf("%s\n", word);
                                return 0;
                            }
                        }
                        else if (i >= 26 && i <= 51)
                        {
                            word[2] = i + 71;
                            string pass = crypt(word, salt);
                            if (strcmp(argv[1], pass) == 0)
                            {
                                printf("%s\n", word);
                                return 0;
                            }
                        }
                    }
                }
            }
        }
        if (n >= 26 && n <= 51)
        {
            word[0] = n + 71;
            for (int j = 0; j <= 51; j++)
            {
                if (j >= 0 && j <= 25)
                {
                    word[1] = j + 65;
                    for (int i = 0; i <= 51; i++)
                    {
                        if (i >= 0 && i <= 25)
                        {
                            word[2] = i + 65;
                            string pass = crypt(word, salt);
                            if (strcmp(argv[1], pass) == 0)
                            {
                                printf("%s\n", word);
                                return 0;
                            }
                        }
                        else if (i >= 26 && i <= 51)
                        {
                            word[2] = i + 71;
                            string pass = crypt(word, salt);
                            if (strcmp(argv[1], pass) == 0)
                            {
                                printf("%s\n", word);
                                return 0;
                            }
                        }
                    }
                }
                if (j <= 26 && j <= 51)
                {
                    word[1] = j + 71;
                    for (int i = 0; i <= 51; i++)
                    {
                        if (i >= 0 && i <= 25)
                        {
                            word[2] = i + 65;
                            string pass = crypt(word, salt);
                            if (strcmp(argv[1], pass) == 0)
                            {
                                printf("%s\n", word);
                                return 0;
                            }
                        }
                        else if (i >= 26 && i <= 51)
                        {
                            word[2] = i + 71;
                            string pass = crypt(word, salt);
                            if (strcmp(argv[1], pass) == 0)
                            {
                                printf("%s\n", word);
                                return 0;
                            }
                        }
                    }
                }
            }
        }
    }

    //four character passwords
    for (int h = 0; h <= 51; h++)
    {
        letter[4] = '\0';
        if (h >= 0 && h <= 25)
        {
            letter[0] = h + 65;
            for (int n = 0; n <= 51; n++)
            {
                if (n >= 0 && n <= 25)
                {
                    letter[1] = n + 65;
                    for (int j = 0; j <= 51; j++)
                    {
                        if (j >= 0 && j <= 25)
                        {
                            letter[2] = j + 65;
                            for (int i = 0; i <= 51; i++)
                            {
                                if (i >= 0 && i <= 25)
                                {
                                    letter[3] = i + 65;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                                else if (i >= 26 && i <= 51)
                                {
                                    letter[3] = i + 71;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                            }
                        }
                        if (j <= 26 && j <= 51)
                        {
                            letter[2] = j + 71;
                            for (int i = 0; i <= 51; i++)
                            {
                                if (i >= 0 && i <= 25)
                                {
                                    letter[2] = i + 65;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                                else if (i >= 26 && i <= 51)
                                {
                                    letter[3] = i + 71;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                            }
                        }
                    }
                }
                if (n >= 26 && n <= 51)
                {
                    letter[1] = n + 71;
                    for (int j = 0; j <= 51; j++)
                    {
                        if (j >= 0 && j <= 25)
                        {
                            letter[2] = j + 65;
                            for (int i = 0; i <= 51; i++)
                            {
                                if (i >= 0 && i <= 25)
                                {
                                    letter[3] = i + 65;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                                else if (i >= 26 && i <= 51)
                                {
                                    letter[3] = i + 71;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                            }
                        }
                        if (j <= 26 && j <= 51)
                        {
                            letter[2] = j + 71;
                            for (int i = 0; i < 51; i++)
                            {
                                if (i >= 0 && i <= 25)
                                {
                                    letter[3] = i + 65;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                                else if (i >= 26 && i <= 51)
                                {
                                    letter[3] = i + 71;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (h >= 26 && h <= 51)
        {
            letter[0] = h + 71;
            for (int n = 0; n <= 51; n++)
            {
                if (n >= 0 && n <= 25)
                {
                    letter[1] = n + 65;
                    for (int j = 0; j <= 51; j++)
                    {
                        if (j >= 0 && j <= 25)
                        {
                            letter[2] = j + 65;
                            for (int i = 0; i <= 51; i++)
                            {
                                if (i >= 0 && i <= 25)
                                {
                                    letter[3] = i + 65;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                                else if (i >= 26 && i <= 51)
                                {
                                    letter[3] = i + 71;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                            }
                        }
                        if (j <= 26 && j <= 51)
                        {
                            letter[2] = j + 71;
                            for (int i = 0; i <= 51; i++)
                            {
                                if (i >= 0 && i <= 25)
                                {
                                    letter[2] = i + 65;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                                else if (i >= 26 && i <= 51)
                                {
                                    letter[3] = i + 71;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                            }
                        }
                    }
                }
                if (n >= 26 && n <= 51)
                {
                    letter[1] = n + 71;
                    for (int j = 0; j <= 51; j++)
                    {
                        if (j >= 0 && j <= 25)
                        {
                            letter[2] = j + 65;
                            for (int i = 0; i <= 51; i++)
                            {
                                if (i >= 0 && i <= 25)
                                {
                                    letter[3] = i + 65;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                                else if (i >= 26 && i <= 51)
                                {
                                    letter[3] = i + 71;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                            }
                        }
                        if (j <= 26 && j <= 51)
                        {
                            letter[2] = j + 71;
                            for (int i = 0; i <= 51; i++)
                            {
                                if (i >= 0 && i <= 25)
                                {
                                    letter[3] = i + 65;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                                else if (i >= 26 && i <= 51)
                                {
                                    letter[3] = i + 71;
                                    string pass = crypt(letter, salt);
                                    if (strcmp(argv[1], pass) == 0)
                                    {
                                        printf("%s\n", letter);
                                        return 0;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}