#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    char s = get_char("s: ");

    if(isdigit(s))
    {
        printf("true\n");
    }
    else
    {
        printf("false");
    }
}