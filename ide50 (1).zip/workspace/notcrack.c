#define _XOPEN_SOURCE
#include <unistd.h>
# include <cs50.h>
# include <stdio.h>
# include <ctype.h>
# include <string.h>

// man crypt

int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./crack hash");
        return 1;
    }

    string salt = "50";
    printf("%s\n", crypt(argv[1], salt));

}