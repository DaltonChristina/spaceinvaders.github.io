#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./vigenere keyword\n");
        return 1;
    }
    for (int i = 0, n = strlen(argv[1]); i < n; i++)
    {
        if (argv[1][i] < 'a' || argv[1][i] > 'z')
        {
            if (argv[1][i] < 'A' || argv[1][i] > 'Z')
            {
                printf("Usage: ./vigenere keyword\n");
                return 1;
            }
        }
    }
    string plain = get_string("plaintext:  ");
    printf("ciphertext: ");
    int j = -1;
    for (int i = 0, n = strlen(plain); i < n; i++)
    {
        j++;
        if (isupper(plain[i]) || islower(plain[i]))
        {
            int key = j % strlen(argv[1]);
            int keyword = argv[1][key];

            int up = 0;
            int low = 0;
            int upper = 0;
            int lower = 0;
            if (isupper(keyword))
            {
                up = (keyword - 13) % 26;
                upper = 65 + (plain[i] - 13 + up) % 26;
                lower = 97 + (plain[i] - 19 + up) % 26;
                if (isupper(plain[i]))
                {
                    printf("%c", (upper));
                }
                else if (islower(plain[i]))
                {
                    printf("%c", (lower));
                }
            }
            else if (islower(keyword))
            {
                low = (keyword - 19) % 26;
                upper = 65 + (plain[i] - 13 + low) % 26;
                lower = 97 + (plain[i] - 19 + low) % 26;
                if (isupper(plain[i]))
                {
                    printf("%c", (upper));
                }
                else if (islower(plain[i]))
                {
                    printf("%c", (lower));
                }
            }
        }
        else
        {
            printf("%c", plain[i]);
            j = j - 1;
        }
    }
    printf("\n");
}