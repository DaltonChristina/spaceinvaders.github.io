#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    int key = atof(argv[1]);
    string plain = get_string("plaintext:  ");
    printf("ciphertext: ");
    for (int i = 0, n = strlen(plain); i < n; i++)
    {
        int upper = 65 + (plain[i] - 13 + key) % 26;
        int lower = 97 + (plain[i] - 19 + key) % 26;
        if (isupper(plain[i]))
        {
            printf("%c", (upper));
        }
        else if (islower(plain[i]))
        {
            printf("%c", (lower));
        }
        else
        {
            printf("%c", plain[i]);
        }
    }
    printf("\n");
}
