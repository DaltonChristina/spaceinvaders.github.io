#include <cs50.h>
#include <math.h>
#include <stdio.h>

int main(int argc, string argv[])
{
    if (argc != 4)
    {
        printf("Usage: ./calc <number> <operation> <number>\n");
        return 1;
    }

    float first = atof(argv[1]);
    float second = atof(argv[3]);
    int number = first / second;
    float answer = first - (second * (float)number);

    switch (argv[2][0])
    {
        case '+':
            printf("%f\n", first + second);
            break;
        case '-':
            printf("%f\n", first - second);
            break;
        case 'x':
            printf("%f\n", first * second);
            break;
        case '/':
            printf("%f\n", first / second);
            break;
        case '%':
            printf("%f\n", answer);
            break;
        default:
            return 1;
    }
    return 0;
}